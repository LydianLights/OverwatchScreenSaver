==============================================
            Overwatch Screen Saver
                   v0.1.0.0
==============================================
To install:
    Move the .scr file to the C:\Windows\
    directory. Once there it should show up
    automatically in the screensaver
    personalization menu.

Alternately:
    Right-click the .scr file and choose
    "install". This will also make it show
    up in the personalization menu, but it
    will disappear if another screensaver is
    chosen and you'll need to reinstall it.


==============================================


Code on GitHub:

https://github.com/LydianLights/OverwatchScreenSaver


==============================================